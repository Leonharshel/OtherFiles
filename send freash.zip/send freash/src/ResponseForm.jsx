import React, { useEffect, useState } from 'react';
import './TicketForm.css';
import { useParams } from 'react-router-dom';
import NavBar from './NavBar';

function ResponseForm() {
  const { ticketId } = useParams();
  const [selectedTicket, setSelectedTicket] = useState(null);

// eslint-disable-next-line react-hooks/exhaustive-deps
// eslint-disable-next-line react-hooks/exhaustive-deps
useEffect(() => {
  async function fetchTicketData() {
    const response = await fetch(
      `https://riskanalysis.azurewebsites.net/Mortgage/SendTicketResponse?id=${ticketId}`
    );
    const ticketInfo = await response.json();
    setSelectedTicket(ticketInfo);
  }
  fetchTicketData();
}, [ticketId]); // add ticketId here

  return (
    <div className="response-form-container">
      <NavBar/>
      {selectedTicket && (
        <form method="get" className="response-form">
          <label htmlFor="TicketId" className="ticket-form-label">
            TicketID:
          </label>
          <input
            id="TicketId"
            value={selectedTicket.ticketId}
            className="ticket-form-input"
            readOnly
          />

          <label htmlFor="Title" className="ticket-form-label">
            Title:
          </label>
          <input
            type="text"
            id="Title"
            value={selectedTicket.title}
            className="ticket-form-input"
            readOnly
          />

          <label htmlFor="Description" className="ticket-form-label">
            Description:
          </label>
          <textarea
            id="Description"
            rows="3"
            value={selectedTicket.content}
            className="ticket-form-input"
            readOnly
          />

          <label htmlFor="Response" className="ticket-form-label">
            Response:
          </label>
          <textarea
            id="Response"
            rows="3"
            value={selectedTicket.response}
            className="ticket-form-input"
            readOnly
          />
        </form>
      )}
    </div>
  );
}

export default ResponseForm;
