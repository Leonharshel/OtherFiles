import React, { useState } from 'react';
import './index.css';
import axios from 'axios';
import NavBar from './NavBar';
import Sidebar from './Sidebar1';
import Header from './Header';
import { Outlet } from 'react-router-dom';

function TicketForm() {
  const initialValues = {
    Id: '',
    Title: '',
    content: ''
  };
  const [formValues, setFormValues] = useState(initialValues);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
    console.log(formValues.Id + ' ' + formValues.Title + ' ' + formValues.content);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    axios
      .post('https://riskanalysis.azurewebsites.net/Mortgage/AddTicket', {
        method: 'POST',
        id: formValues.Id,
        title: formValues.Title,
        content: formValues.content,
        ticketDate: 'string',
        Response: 'NULL'
      })
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.error('Error signing up:', error);
      });
  };

  return (
    <div>
      <Header/>
      <NavBar />
      <Sidebar/>
      <h1>Have a Question? Raise a Ticket!</h1>
      <form onSubmit={handleSubmit} className="ticket-form">
        <label htmlFor="Id" className="ticket-form-label">
          Id:
        </label>
        <input
          type="text"
          className="form-control"
          id="Id"
          name="Id"
          value={formValues.Id}
          placeholder="Enter your Id"
          onChange={handleChange}
          ClassName="ticket-form-input"
        />
        <br />
        <label htmlFor="Title" className="ticket-form-label">
          Title:
        </label>
        <input
          type="text"
          className="form-control"
          id="Title"
          name="Title"
          value={formValues.Title}
          placeholder="Provide your Issue"
          onChange={handleChange}
          ClassName="ticket-form-input"
        />
        <br />
        <label htmlFor="content" className="ticket-form-label">
          content:
        </label>
        <textarea
          id="content"
          rows="3"
          value={formValues.content}
          name="content"
          placeholder="Enter the Detailed content"
          onChange={handleChange}
          className="ticket-form-input"
        />
        <br />
        <button type="submit" className="ticket-form-button">
          Submit
        </button>
      </form>
<Outlet></Outlet>
    </div>

  );
}
export default TicketForm;
