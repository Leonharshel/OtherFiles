import React from 'react';
import './App.css';

import "bootstrap/dist/css/bootstrap.min.css";

function App() {

  return (
    <div className="App">
      <header className="header">
        <div className="logo">
          
          <img src={process.env.PUBLIC_URL + './logo1.png'} alt="Company Logo" />
          
        </div>
       
      </header>
    </div>
  );
}

export default App;
