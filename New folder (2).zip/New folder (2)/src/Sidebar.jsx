import React from 'react';
import { NavLink } from 'react-router-dom';
import logo from './logo.png';
import './Styles.css';

function Sidebar(){
    
    return (<>
            <nav class="col-md-2 d-none d-md-block bg-blue sidebar">
                <center><img src={logo} className="navbar-brand" width="150" alt="Tech support" /></center>
                <ul class="nav flex-column">
                    <li className="nav-item">
                        <NavLink to="/" onlyActiveOnIndex={true} className="nav-link" activeClassName="active">
                            <i class="fas fa-home"></i>
                            Home Page
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/RaiseTicket" className="nav-link" activeClassName="active">
                            <i class="fas fa-ticket-alt"></i>
                            Submit a Ticket
                        </NavLink>
                    </li>
                </ul>
            </nav>
        </>);
    }

export default Sidebar