import React,{ useState,useEffect} from 'react';
import { Link } from 'react-router-dom';
import './Styles.css';
import "bootstrap/dist/css/bootstrap.min.css";
import './TicketForm.jsx';
import './Sidebar1.css';


function Sidebar() {

  const [tickets, setTickets] = useState([]);
  

  useEffect(() => {
    const fetchTicketIds = async () => {
     await fetch('https://riskanalysis.azurewebsites.net/Mortgage/GetTicketHistorybyId?Id=12')
        .then(response => response.json())
        .then(data => setTickets(data));
    }
    fetchTicketIds();
  }, []);
  
  

  return (
    <nav className="tkt col-md-2 d-none d-md-block bg-blue sidebar">

      <p><b> Ticket History</b></p>
      <ul>
        {tickets.map(ticket => (
          <li key={ticket.ticketId} >
            <Link to={`ticket/${ticket.ticketId}`}>
              Ticket#{ticket.ticketId}
            </Link> 
          </li>
        ))}
      </ul>
    </nav>
  );
}


export default Sidebar;
